export default class GalleryService {

    //Fetch de les categories
    static async getCategories() {
        const res = await fetch(
            "https://theteacher.codiblau.com/public/exercicis/galeria/categories-list"
        );
        return await res.json();
    }

    //Fetch de les obres d'art que han de substituir a les hard-coded
    static async getArtWorks() {
        const res = await fetch(
            "https://theteacher.codiblau.com/public/exercicis/galeria/list"
        );
        return await res.json();
    }

    //Post de les obres creades a través de formulari
    static async saveArtWork(artwork) {
        const res = await fetch(
            "https://theteacher.codiblau.com/public/exercicis/galeria/save",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                },
                body: JSON.stringify(artwork)
            }
        );

        const responseText = await res.text();

        try {
            const data = JSON.parse(responseText);

            if (!res.ok) {
                throw new Error(data.message || "Error desconegut del servidor");
            }
            return data;

        } catch (error) {

            if (!res.ok) {
                throw new Error(responseText);
            }
            return { message: responseText };
        }
    }
}
