import GalleryService from "./service/GalleryService.js";
import GalleryView from "./view/GalleryView.js";

let allArtworks = [];

//Inici de execució de la web
(async () => {
    try {
        console.log("Iniciando aplicación...");

        const categories = await GalleryService.getCategories();
        GalleryView.renderCategories(categories, filterByCategory);
        GalleryView.fillCategorySelect(categories);

        await loadArtworks();

        initFormListener();

    } catch (error) {
        console.error("Error al iniciar la app:", error);
    }
})();

//Funció per carregar les obres rebudes a través de getArtWorks() i ordena per data
async function loadArtworks() {
    try {
        const data = await GalleryService.getArtWorks();

        allArtworks = data.sort((a, b) => new Date(a.data) - new Date(b.data));

        GalleryView.renderGallery(allArtworks, (url) => window.setImage(url));
    } catch (error) {
        console.error("Error cargando obras:", error);
    }
}

//Exercici c)
function filterByCategory(category) {
    if (category === "Totes") {
        GalleryView.renderGallery(allArtworks, (url) => window.setImage(url));
    } else {
        const filtered = allArtworks.filter(art => art.categoria === category);
        GalleryView.renderGallery(filtered, (url) => window.setImage(url));
    }
}

//Mètode de creació de obra nova a través de formulari
function initFormListener() {
    const sendBtn = document.getElementById("form-send");
    if (!sendBtn) return;

    sendBtn.addEventListener("click", async (e) => {
        e.preventDefault();

        const titolInput = document.getElementById("form-titol");
        const urlInput = document.getElementById("form-url");
        const dataInput = document.getElementById("form-data");
        const catInput = document.getElementById("form-categoria");

        if (!titolInput.value || !urlInput.value || !dataInput.value) {
            alert("Si us plau, omple tots els camps.");
            return;
        }

        const newArt = {
            titol: titolInput.value,
            url: urlInput.value,
            data: dataInput.value,
            categoria: catInput.value
        };

        try {
            await GalleryService.saveArtWork(newArt);

            alert("Obra desada correctament");

            await loadArtworks();

            titolInput.value = "";
            urlInput.value = "";
            dataInput.value = "";

        } catch (error) {
            console.error(error);
            alert("Error al guardar: " + error.message);
        }
    });
}