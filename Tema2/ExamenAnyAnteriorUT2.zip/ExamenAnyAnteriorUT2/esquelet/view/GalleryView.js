export default class GalleryView {

    //Exercici b)
    static renderGallery(artworks, onImageClick) {
        const gallery = document.getElementById("contain");
        gallery.innerHTML = "";

        artworks.forEach(art => {
            const item = document.createElement("div");
            item.className = "four columns item";
            item.dataset.category = art.categoria;

            item.innerHTML = `
                <div class="caption">
                    <img src="${art.url}" class="pic">
                </div>
                <h4>${art.titol}</h4>
                <p>Publicat el ${art.data}</p>
                <button>Veure al canvas</button>
            `;

            item.querySelector("button").addEventListener("click", () => {
                onImageClick(art.url);
            });

            gallery.appendChild(item);
        });
    }

    //Es creen els botons de categories nous i es van posant els noms que es reb a través del fetch
    static renderCategories(categories, onFilter) {
        const filters = document.getElementById("filters");
        filters.innerHTML = "";

        const all = document.createElement("li");
        all.innerHTML = "<a href='#'>Totes</a>";
        all.onclick = () => onFilter("Totes");
        filters.appendChild(all);

        categories.forEach(cat => {
            const li = document.createElement("li");
            li.innerHTML = `<a href="#">${cat}</a>`;
            li.onclick = () => onFilter(cat);
            filters.appendChild(li);
        });
    }

    //Mètode per "rellenar" el botó desplegable del formulari de creació de obra
    static fillCategorySelect(categories) {
        const select = document.getElementById("form-categoria");
        select.innerHTML = "";

        categories.forEach(cat => {
            const option = document.createElement("option");
            option.value = cat;
            option.textContent = cat;
            select.appendChild(option);
        });
    }
}
