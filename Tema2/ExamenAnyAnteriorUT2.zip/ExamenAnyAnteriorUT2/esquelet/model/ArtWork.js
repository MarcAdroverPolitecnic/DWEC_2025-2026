export default class ArtWork {
    constructor(id, titol, url, data, categoria) {
        this.id = id;
        this.titol = titol;
        this.url = url;
        this.data = data;
        this.categoria = categoria;
    }
}
